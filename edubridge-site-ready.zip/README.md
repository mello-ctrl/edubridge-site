# Edu‑Bridge — Learning for Every Child

A lightweight, mobile‑friendly site to connect **rural learners** in South Africa to **offline lesson packs**, **low‑data resources** and **short mentor Q&A** sessions.

> ✨ Live demo (GitHub Pages): enable in **Settings → Pages** after pushing this repo.

## 🚀 Features
- **Homepage** with value proposition and clear CTAs
- **Explore hub** with subject cards and sample links (replace with your own PDFs/ZIPs/quizzes)
- **Responsive** layout (works on phones first)
- **Low‑data** friendly design
- Simple **mobile nav**

## 📂 Project Structure
```
edubridge-site/
├── index.html          # Home
├── explore.html        # Resource Hub
├── css/
│   └── style.css
├── js/
│   └── script.js
└── images/
    └── favicon.png     # (optional placeholder)
```

## 🧭 Getting Started (local)
1. Clone or download this repo  
2. Open `index.html` in your browser

No build tools required.

## 🔗 Replace these placeholders
- In **explore.html**: replace `sample.pdf`, `maths-pack.zip` etc. with your real links (Google Drive, school LMS, etc.).
- In the footer and contact sections: set your **email** and **phone**.
- Update the **favicon** in `/images/favicon.png` (optional).

## 🌐 Publish to GitHub Pages
1. Push to `main` branch
2. Go to **Settings → Pages**
3. **Source:** `Deploy from a branch`
4. **Branch:** `main` and **Folder:** `/root`, then **Save**
5. Your site will be live at `https://<your-username>.github.io/edubridge-site/` within a few minutes.

## ✅ Checklist before sharing
- [ ] All placeholder links replaced
- [ ] Spelling & grammar checked
- [ ] Mobile view tested
- [ ] GitHub Pages enabled and URL added to repo **About** section

## 📝 License
MIT — feel free to adapt for your school/NGO use.
